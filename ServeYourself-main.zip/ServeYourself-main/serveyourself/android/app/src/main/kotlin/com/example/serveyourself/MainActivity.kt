package com.example.serveyourself

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
