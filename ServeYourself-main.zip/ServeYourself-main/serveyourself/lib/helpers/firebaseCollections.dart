class FirebaseCollections {
  static const String users = 'users';
  static const String meals = 'meals';
  static const String favourites = 'favourites';
  static const String orders = 'orders';
  static const String reviews = 'reviews';
  static const String calendar = 'calendar';
}
