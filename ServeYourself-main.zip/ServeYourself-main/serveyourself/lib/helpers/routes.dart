class Routes {
  static const String routeLogin = "LoginPage";
  static const String routeSetting = "SettingPage";
  static const String routeSignUp = "SignupPage";
  static const String routeFavoris = "FavoritesPage";
  static const String routeProfil = "ProfilPage";
  static const String routeHome = "HomePage";
  static const String routeCalendar = "CalendarPage";
  static const String routeSearchIngredient = 'search_ingredient';
  static const String routeSearchCategory = 'search_category';

  static const String routeMealPage = 'MealPageView';
  


  static const String routeDetails = 'details';
  static const String routeTest = 'test';
  static const String routeRandomMeal = "RandomMealPage";
}
