class Constants {
  static const String appName = 'Serve Yourself';
}
