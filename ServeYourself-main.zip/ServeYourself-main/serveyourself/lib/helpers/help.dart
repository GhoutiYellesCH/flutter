import 'package:serveyourself/models/meal.dart';

class ExMeals {
  static Meal meal1 = Meal(
    idMeal: "52767",
    strMeal: "Bakewell tart",
    strMealAlternate: null,
    strCategory: "Dessert",
    strArea: "British",
    strInstructions:
        "To make the pastry, measure the flour into a bowl and rub in the butter with your fingertips until the mixture resembles fine breadcrumbs. Add the water, mixing to form a soft dough.\r\nRoll out the dough on a lightly floured work surface and use to line a 20cm/8in flan tin. Leave in the fridge to chill for 30 minutes.\r\nPreheat the oven to 200C/400F/Gas 6 (180C fan).\r\nLine the pastry case with foil and fill with baking beans. Bake blind for about 15 minutes, then remove the beans and foil and cook for a further five minutes to dry out the base.\r\nFor the filling, spread the base of the flan generously with raspberry jam.\r\nMelt the butter in a pan, take off the heat and then stir in the sugar. Add ground almonds, egg and almond extract. Pour into the flan tin and sprinkle over the flaked almonds.\r\nBake for about 35 minutes. If the almonds seem to be browning too quickly, cover the tart loosely with foil to prevent them burning.",
    strMealThumb:
        "https://www.themealdb.com/images/media/meals/wyrqqq1468233628.jpg",
    strTags: "Tart,Baking,Alcoholic",
    strYoutube: "https://www.youtube.com/watch?v=1ahpSTf_Pvk",
    ingredients: [
      "plain flour",
      "chilled butter",
      "cold water",
      "raspberry jam",
      "butter",
      "caster sugar",
      "ground almonds",
      "free-range egg, beaten",
      "almond extract",
      "flaked almonds",
    ],
    measures: [
      "175g/6oz",
      "75g/2½oz",
      "2-3 tbsp",
      "1 tbsp",
      "125g/4½oz",
      "125g/4½oz",
      "125g/4½oz",
      "1",
      "½ tsp",
      "50g/1¾oz",
    ],
    descriptions:
        "A classic British dessert featuring a buttery pastry crust filled with a layer of raspberry jam and a rich almond frangipane, topped with flaked almonds. Perfect for tea time or a sweet indulgence.",
  );

  static Meal meal2 = Meal(
    idMeal: "52792",
    strMeal: "Bread and Butter Pudding",
    strMealAlternate: null,
    strCategory: "Dessert",
    strArea: "British",
    strInstructions:
        "Grease a 1 litre/2 pint pie dish with butter.\r\nCut the crusts off the bread. Spread each slice with on one side with butter, then cut into triangles.\r\nArrange a layer of bread, buttered-side up, in the bottom of the dish, then add a layer of sultanas. Sprinkle with a little cinnamon, then repeat the layers of bread and sultanas, sprinkling with cinnamon, until you have used up all of the bread. Finish with a layer of bread, then set aside.\r\nGently warm the milk and cream in a pan over a low heat to scalding point. Don't let it boil.\r\nCrack the eggs into a bowl, add three quarters of the sugar and lightly whisk until pale.\r\nAdd the warm milk and cream mixture and stir well, then strain the custard into a bowl.\r\nPour the custard over the prepared bread layers and sprinkle with nutmeg and the remaining sugar and leave to stand for 30 minutes.\r\nPreheat the oven to 180C/355F/Gas 4.\r\nPlace the dish into the oven and bake for 30-40 minutes, or until the custard has set and the top is golden-brown.",
    strMealThumb:
        "https://www.themealdb.com/images/media/meals/xqwwpy1483908697.jpg",
    strTags: "Pudding,Brunch",
    strYoutube: "https://www.youtube.com/watch?v=Vz5W1-BmOE4",
    ingredients: [
      "butter",
      "bread",
      "sultanas",
      "cinnamon",
      "milk",
      "double cream",
      "eggs",
      "sugar",
      "nutmeg",
    ],
    measures: [
      "25g/1oz",
      "8 thin slices",
      "50g/2oz",
      "2 tsp",
      "350ml/12fl",
      "50ml/2fl oz",
      "2 free-range",
      "25g/1oz",
      "grated, to taste",
    ],
    descriptions:
        "A comforting British dessert made with layers of buttered bread, sultanas, and cinnamon, soaked in a creamy custard and baked until golden. Ideal for a cozy brunch or dessert.",
  );

  static Meal meal3 = Meal(
    idMeal: "52803",
    strMeal: "Beef Wellington",
    strMealAlternate: null,
    strCategory: "Beef",
    strArea: "British",
    strInstructions:
        "Put the mushrooms into a food processor with some seasoning and pulse to a rough paste. Scrape the paste into a pan and cook over a high heat for about 10 mins, tossing frequently, to cook out the moisture from the mushrooms. Spread out on a plate to cool.\r\nHeat in a frying pan and add a little olive oil. Season the beef and sear in the hot pan for 30 secs only on each side. (You don't want to cook it at this stage, just colour it). Remove the beef from the pan and leave to cool, then brush all over with the mustard.\r\nLay a sheet of cling film on a work surface and arrange the Parma ham slices on it, in slightly overlapping rows. With a palette knife, spread the mushroom paste over the ham, then place the seared beef fillet in the middle. Keeping a tight hold of the cling film from the edge, neatly roll the Parma ham and mushrooms around the beef to form a tight barrel shape. Twist the ends of the cling film to secure. Chill for 15-20 mins to allow the beef to set and keep its shape.\r\nRoll out the puff pastry on a floured surface to a large rectangle, the thickness of a £1 coin. Remove the cling film from the beef, then lay in the centre. Brush the surrounding pastry with egg yolk. Fold the ends over, the wrap the pastry around the beef, cutting off any excess. Turn over, so the seam is underneath, and place on a baking sheet. Brush over all the pastry with egg and chill for about 15 mins to let the pastry rest.\r\nHeat the oven to 200C, 400F, gas 6.\r\nLightly score the pastry at 1cm intervals and glaze again with beaten egg yolk. Bake for 20 minutes, then lower the oven setting to 180C, 350F, gas 4 and cook for another 15 mins. Allow to rest for 10-15 mins before slicing and serving with the side dishes of your choice. The beef should still be pink in the centre when you serve it.",
    strMealThumb:
        "https://www.themealdb.com/images/media/meals/vvpprx1487325699.jpg",
    strTags: "Meat,Stew",
    strYoutube: "https://www.youtube.com/watch?v=FS8u1RBdf6I",
    ingredients: [
      "mushrooms",
      "English Mustard",
      "Olive Oil",
      "Beef Fillet",
      "Parma ham",
      "Puff Pastry",
      "Flour",
      "Egg Yolks",
    ],
    measures: [
      "400g",
      "1-2tbsp",
      "Dash",
      "750g piece",
      "6-8 slices",
      "500g",
      "Dusting",
      "2 Beaten",
    ],
    descriptions:
        "A luxurious British dish featuring a beef fillet coated with mustard, wrapped in mushroom duxelles and Parma ham, then encased in puff pastry and baked to perfection. Ideal for special occasions.",
  );

  static Meal meal4 = Meal(
    idMeal: "52807",
    strMeal: "Baingan Bharta",
    strMealAlternate: null,
    strCategory: "Vegetarian",
    strArea: "Indian",
    strInstructions:
        "Rinse the baingan (eggplant or aubergine) in water. Pat dry with a kitchen napkin. Apply some oil all over and\r\nkeep it for roasting on an open flame. You can also grill the baingan or roast in the oven. But then you won't get\r\nthe smoky flavor of the baingan. Keep the eggplant turning after a 2 to 3 minutes on the flame, so that its evenly\r\ncooked. You could also embed some garlic cloves in the baingan and then roast it.\r\n2. Roast the aubergine till its completely cooked and tender. With a knife check the doneness. The knife should slid\r\neasily in aubergines without any resistance. Remove the baingan and immerse in a bowl of water till it cools\r\ndown.\r\n3. You can also do the dhungar technique of infusing charcoal smoky flavor in the baingan. This is an optional step.\r\nUse natural charcoal for this method. Heat a small piece of charcoal on flame till it becomes smoking hot and red.\r\n4. Make small cuts on the baingan with a knife. Place the red hot charcoal in the same plate where the roasted\r\naubergine is kept. Add a few drops of oil on the charcoal. The charcoal would begin to smoke.\r\n5. As soon as smoke begins to release from the charcoal, cover the entire plate tightly with a large bowl. Allow the\r\ncharcoal smoke to get infused for 1 to 2 minutes. The more you do, the more smoky the baingan bharta will\r\nbecome. I just keep for a minute. Alternatively, you can also do this dhungar method once the baingan bharta is\r\ncooked, just like the way we do for Dal Tadka.\r\n6. Peel the skin from the roasted and smoked eggplant.\r\n7. Chop the cooked eggplant finely or you can even mash it.\r\n8. In a kadai or pan, heat oil. Then add finely chopped onions and garlic.\r\n9. Saute the onions till translucent. Don't brown them.\r\n10. Add chopped green chilies and saute for a minute.\r\n11. Add the chopped tomatoes and mix it well.\r\n12. Bhuno (saute) the tomatoes till the oil starts separating from the mixture.\r\n13. Now add the red chili powder. Stir and mix well.\r\n14. Add the chopped cooked baingan.\r\n15. Stir and mix the chopped baingan very well with the onion-tomato masala mixture.\r\n16. Season with salt. Stir and saute for some more 4 to 5 minutes more.\r\n17. Finally stir in the coriander leaves with the baingan bharta or garnish it with them. Serve Baingan Bharta with\r\nphulkas, rotis or chapatis. It goes well even with bread, toasted or grilled bread and plain rice or jeera rice.",
    strMealThumb:
        "https://www.themealdb.com/images/media/meals/urtpqw1487341253.jpg",
    strTags: "Spicy,Bun,Calorific",
    strYoutube: "https://www.youtube.com/watch?v=-84Zz2EP4h4",
    ingredients: [
      "Aubergine",
      "Onion",
      "Tomatoes",
      "Garlic",
      "Green Chilli",
      "Red Chilli Powder",
      "Oil",
      "Coriander Leaves",
      "salt",
    ],
    measures: [
      "1 large",
      "½ cup",
      "1 cup",
      "6 cloves",
      "1",
      "¼ teaspoon",
      "1.5 tablespoon",
      "1 tablespoon chopped",
      "as required",
    ],
    descriptions:
        "A smoky Indian vegetarian dish made from roasted eggplant mashed and cooked with onions, tomatoes, garlic, and spices, offering a rich, spicy flavor. Perfect with flatbreads or rice.",
  );

  static Meal meal5 = Meal(
    idMeal: "52812",
    strMeal: "Beef Brisket Pot Roast",
    strMealAlternate: null,
    strCategory: "Beef",
    strArea: "American",
    strInstructions:
        "1 Prepare the brisket for cooking: On one side of the brisket there should be a layer of fat, which you want. If there are any large chunks of fat, cut them off and discard them. Large pieces of fat will not be able to render out completely.\r\nUsing a sharp knife, score the fat in parallel lines, about 3/4-inch apart. Slice through the fat, not the beef. Repeat in the opposite direction to make a cross-hatch pattern.\r\nSalt the brisket well and let it sit at room temperature for 30 minutes.\r\n \r\n2 Sear the brisket: You'll need an oven-proof, thick-bottomed pot with a cover, or Dutch oven, that is just wide enough to hold the brisket roast with a little room for the onions.\r\nPat the brisket dry and place it, fatty side down, into the pot and place it on medium high heat. Cook for 5-8 minutes, lightly sizzling, until the fat side is nicely browned. (If the roast seems to be cooking too fast, turn the heat down to medium. You want a steady sizzle, not a raging sear.)\r\nTurn the brisket over and cook for a few minutes more to brown the other side.\r\n\r\n3 Sauté the onions and garlic: When the brisket has browned, remove it from the pot and set aside. There should be a couple tablespoons of fat rendered in the pot, if not, add some olive oil.\r\nAdd the chopped onions and increase the heat to high. Sprinkle a little salt on the onions. Sauté, stirring often, until the onions are lightly browned, 5-8 minutes. Stir in the garlic and cook 1-2 more minutes.\r\n \r\n4 Return brisket to pot, add herbs, stock, bring to simmer, cover, cook in oven: Preheat the oven to 300°F. Use kitchen twine to tie together the bay leaves, rosemary and thyme.\r\nMove the onions and garlic to the sides of the pot and nestle the brisket inside. Add the beef stock and the tied-up herbs. Bring the stock to a boil on the stovetop.\r\nCover the pot, place the pot in the 300°F oven and cook for 3 hours. Carefully flip the brisket every hour so it cooks evenly.\r\n \r\n5 Add carrots, continue to cook: After 3 hours, add the carrots. Cover the pot and cook for 1 hour more, or until the carrots are cooked through and the brisket is falling-apart tender.\r\n6 Remove brisket to cutting board, tent with foil: When the brisket is falling-apart tender, take the pot out of the oven and remove the brisket to a cutting board. Cover it with foil. Pull out and discard the herbs.\r\n7 Make sauce (optional): At this point you have two options. You can serve as is, or you can make a sauce with the drippings and some of the onions. If you serve as is, skip this step.\r\nTo make a sauce, remove the carrots and half of the onions, set aside and cover them with foil. Pour the ingredients that are remaining into the pot into a blender, and purée until smooth. If you want, add 1 tablespoon of mustard to the mix. Put into a small pot and keep warm.\r\n8 Slice the meat across the grain: Notice the lines of the muscle fibers of the roast. This is the \"grain\" of the meat. Slice the meat perpendicular to these lines, or across the grain (cutting this way further tenderizes the meat), in 1/4-inch to 1/2-inch slices.\r\nServe with the onions, carrots and gravy. Serve with mashed, roasted or boiled potatoes, egg noodles or polenta.",
    strMealThumb:
        "https://www.themealdb.com/images/media/meals/ursuup1487348423.jpg",
    strTags: "Meat",
    strYoutube: "https://www.youtube.com/watch?v=gh48wM6bPWQ",
    ingredients: [
      "Beef Brisket",
      "Salt",
      "Onion",
      "Garlic",
      "Thyme",
      "Rosemary",
      "Bay Leaves",
      "beef stock",
      "Carrots",
      "Mustard",
      "Potatoes",
    ],
    measures: [
      "4-5 pound",
      "Dash",
      "3",
      "5 cloves",
      "1 Sprig",
      "1 sprig",
      "4",
      "2 cups",
      "3 Large",
      "1 Tbsp",
      "4 Mashed",
    ],
    descriptions:
        "A hearty American dish featuring slow-cooked beef brisket with a rich, savory flavor, accompanied by carrots, onions, and herbs, served with a smooth gravy.",
  );

  static Meal meal6 = Meal(
    idMeal: "52824",
    strMeal: "Beef Sunday Roast",
    strMealAlternate: null,
    strCategory: "Beef",
    strArea: "British",
    strInstructions:
        "Cook the Broccoli and Carrots in a pan of boiling water until tender.\r\n\r\nRoast the Beef and Potatoes in the oven for 45mins, the potatoes may need to be checked regularly to not overcook.\r\n\r\nTo make the Yorkshire puddings:\r\nHeat oven to 230C/fan 210C/gas 8. Drizzle a little sunflower oil evenly into 2 x 4-hole Yorkshire pudding tins or a 12-hole non-stick muffin tin and place in the oven to heat through\r\nTo make the batter, tip 140g plain flour into a bowl and beat in four eggs until smooth. Gradually add 200ml milk and carry on beating until the mix is completely lump-free. Season with salt and pepper. Pour the batter into a jug, then remove the hot tins from the oven. Carefully and evenly pour the batter into the holes. Place the tins back in the oven and leave undisturbed for 20-25 mins until the puddings have puffed up and browned. Serve immediately.\r\n\r\nPlate up and add the Gravy as desired.",
    strMealThumb:
        "https://www.themealdb.com/images/media/meals/ssrrrs1503664277.jpg",
    strTags: "MainMeal",
    strYoutube: "https://www.youtube.com/watch?v=2l3-dBdNehY",
    ingredients: [
      "Beef",
      "Broccoli",
      "Potatoes",
      "Carrots",
      "plain flour",
      "Eggs",
      "milk",
      "sunflower oil",
    ],
    measures: [
      "8 slices",
      "12 florets",
      "1 Packet",
      "1 Packet",
      "140g",
      "4",
      "200ml",
      "drizzle (for cooking)",
    ],
    descriptions:
        "A traditional British Sunday roast featuring tender beef, roasted potatoes, broccoli, carrots, and homemade Yorkshire puddings, perfect for a family gathering.",
  );

  static Meal meal7 = Meal(
    idMeal: "52826",
    strMeal: "Braised Beef Chilli",
    strMealAlternate: null,
    strCategory: "Beef",
    strArea: "Mexican",
    strInstructions:
        "Preheat the oven to 120C/225F/gas mark 1.\r\n\r\nTake the meat out of the fridge to de-chill. Pulse the onions and garlic in a food processor until finely chopped. Heat 2 tbsp olive oil in a large casserole and sear the meat on all sides until golden.\r\n\r\nSet to one side and add another small slug of oil to brown the chorizo. Remove and add the onion and garlic, spices, herbs and chillies then cook until soft in the chorizo oil. Season with salt and pepper and add the vinegar, tomatoes, ketchup and sugar.\r\n\r\nPut all the meat back into the pot with 400ml water (or red wine if you prefer), bring up to a simmer and cook, covered, in the low oven.\r\n\r\nAfter 2 hours, check the meat and add the beans. Cook for a further hour and just before serving, pull the meat apart with a pair of forks.",
    strMealThumb:
        "https://www.themealdb.com/images/media/meals/uuqvwu1504629254.jpg",
    strTags: null,
    strYoutube: "https://www.youtube.com/watch?v=z4kSoJgsu6Y",
    ingredients: [
      "Beef",
      "Onions",
      "Garlic",
      "Olive oil",
      "Chorizo",
      "Cumin",
      "Allspice",
      "Cloves",
      "Cinnamon stick",
      "Bay Leaves",
      "Oregano",
      "Ancho Chillies",
      "Balsamic Vinegar",
      "Plum Tomatoes",
      "Tomato Ketchup",
      "Dark Brown Sugar",
      "Borlotti Beans",
    ],
    measures: [
      "1kg",
      "3",
      "4 cloves",
      "Dash",
      "300g",
      "2 tsp",
      "2 tsp",
      "1 tsp",
      "1 large",
      "3",
      "2 tsp dried",
      "2 ancho",
      "3 tbsp",
      "2 x 400g",
      "2 tbsp",
      "2 tbsp",
      "2 x 400g tins",
    ],
    descriptions:
        "A robust Mexican-inspired chili with tender braised beef, chorizo, beans, and a blend of spices, slow-cooked for deep flavors, great with rice or bread.",
  );

  static Meal meal8 = Meal(
    idMeal: "52834",
    strMeal: "Beef Stroganoff",
    strMealAlternate: null,
    strCategory: "Beef",
    strArea: "Russian",
    strInstructions:
        "Heat the olive oil in a non-stick frying pan then add the sliced onion and cook on a medium heat until completely softened, so around 15 mins, adding a little splash of water if they start to stick at all. Crush in the garlic and cook for a 2-3 mins further, then add the butter. Once the butter is foaming a little, add the mushrooms and cook for around 5 mins until completely softened. Season everything well, then tip onto a plate.\r\nTip the flour into a bowl with a big pinch of salt and pepper, then toss the steak in the seasoned flour. Add the steak pieces to the pan, splashing in a little oil if the pan looks particularly dry, and fry for 3-4 mins, until well coloured. Tip the onions and mushrooms back into the pan. Whisk the crème fraîche, mustard and beef stock together, then pour into the pan. Cook over a medium heat for around 5 mins. Scatter with parsley, then serve with pappardelle or rice.",
    strMealThumb:
        "https://www.themealdb.com/images/media/meals/svprys1511176755.jpg",
    strTags: null,
    strYoutube: "https://www.youtube.com/watch?v=PQHgQX1Ss74",
    ingredients: [
      "Olive Oil",
      "Onions",
      "Garlic",
      "Butter",
      "Mushrooms",
      "Beef Fillet",
      "Plain Flour",
      "Creme Fraiche",
      "English Mustard",
      "Beef Stock",
      "Parsley",
    ],
    measures: [
      "1 tbls",
      "1",
      "1 clove",
      "1 tbsp",
      "250g",
      "500g",
      "1tbsp",
      "150g",
      "1 tbsp",
      "100ml",
      "Topping",
    ],
    descriptions:
        "A creamy Russian dish featuring tender beef fillet strips in a rich mushroom, onion, and crème fraîche sauce, served with pappardelle or rice.",
  );

  static Meal meal9 = Meal(
    idMeal: "52842",
    strMeal: "Broccoli & Stilton Soup",
    strMealAlternate: null,
    strCategory: "Starter",
    strArea: "British",
    strInstructions:
        "Heat the rapeseed oil in a large saucepan and then add the onions. Cook on a medium heat until soft. Add a splash of water if the onions start to catch.\r\n\r\nAdd the celery, leek, potato and a knob of butter. Stir until melted, then cover with a lid. Allow to sweat for 5 minutes. Remove the lid.\r\n\r\nPour in the stock and add any chunky bits of broccoli stalk. Cook for 10 – 15 minutes until all the vegetables are soft.\r\n\r\nAdd the rest of the broccoli and cook for a further 5 minutes. Carefully transfer to a blender and blitz until smooth. Stir in the stilton, allowing a few lumps to remain. Season with black pepper and serve.",
    strMealThumb:
        "https://www.themealdb.com/images/media/meals/tvvxpv1511191952.jpg",
    strTags: null,
    strYoutube: "https://www.youtube.com/watch?v=_HgVLpmNxTY",
    ingredients: [
      "Rapeseed Oil",
      "Onion",
      "Celery",
      "Leek",
      "Potatoes",
      "Butter",
      "Vegetable Stock",
      "Broccoli",
      "Stilton Cheese",
    ],
    measures: [
      "2 tblsp",
      "1 finely chopped",
      "1",
      "1 sliced",
      "1 medium",
      "1 knob",
      "1 litre hot",
      "1 Head chopped",
      "140g",
    ],
    descriptions:
        "A creamy British starter combining broccoli with tangy Stilton cheese, blended with vegetables for a smooth, comforting soup, ideal for chilly days.",
  );

  static Meal meal10 = Meal(
    idMeal: "52848",
    strMeal: "Bean & Sausage Hotpot",
    strMealAlternate: null,
    strCategory: "Miscellaneous",
    strArea: "British",
    strInstructions:
        "In a large casserole, fry the sausages until brown all over – about 10 mins.\r\n\r\nAdd the tomato sauce, stirring well, then stir in the beans, treacle or sugar and mustard. Bring to the simmer, cover and cook for 30 mins. Great served with crusty bread or rice.",
    strMealThumb:
        "https://www.themealdb.com/images/media/meals/vxuyrx1511302687.jpg",
    strTags: null,
    strYoutube: "https://www.youtube.com/watch?v=B0YX0yPX4Wo",
    ingredients: [
      "Sausages",
      "Tomato Sauce",
      "Butter Beans",
      "Black Treacle",
      "English Mustard",
    ],
    measures: [
      "8 large",
      "1 Jar",
      "1200g",
      "1 tbls",
      "1 tsp",
    ],
    descriptions:
        "A simple yet flavorful British dish featuring browned sausages simmered with butter beans in a rich tomato sauce, enhanced with mustard and treacle.",
  );

  static Meal meal11 = Meal(
    idMeal: "52855",
    strMeal: "Banana Pancakes",
    strMealAlternate: null,
    strCategory: "Dessert",
    strArea: "American",
    strInstructions:
        "In a bowl, mash the banana with a fork until it resembles a thick purée. Stir in the eggs, baking powder and vanilla.\r\nHeat a large non-stick frying pan or pancake pan over a medium heat and brush with half the oil. Using half the batter, spoon two pancakes into the pan, cook for 1-2 mins each side, then tip onto a plate. Repeat the process with the remaining oil and batter. Top the pancakes with the pecans and raspberries.",
    strMealThumb:
        "https://www.themealdb.com/images/media/meals/sywswr1511383814.jpg",
    strTags: "Breakfast,Desert,Sweet",
    strYoutube: "https://www.youtube.com/watch?v=kSKtb2Sv-_U",
    ingredients: [
      "Banana",
      "Eggs",
      "Baking Powder",
      "Vanilla Extract",
      "Oil",
      "Pecan Nuts",
      "Raspberries",
    ],
    measures: [
      "1 large",
      "2 medium",
      "pinch",
      "spinkling",
      "1 tsp",
      "25g",
      "125g",
    ],
    descriptions:
        "Light and fluffy American pancakes made with mashed bananas, topped with pecans and raspberries, perfect for a sweet breakfast or dessert.",
  );
}