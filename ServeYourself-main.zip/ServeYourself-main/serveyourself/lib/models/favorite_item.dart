class FavoriteItem {
  final String title;
  final String imageUrl;
  final double rating;

  FavoriteItem({
    required this.title,
    required this.imageUrl,
    required this.rating,
  });
}

