import 'package:flutter/cupertino.dart';

@immutable
abstract class AbstractAppEvent {
  const AbstractAppEvent();
}
