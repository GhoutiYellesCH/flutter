// import 'package:flutter/material.dart';
//
// class MealPage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text('Meal Page')),
//       body: Center(child: Text('Meal Page')),
//     );
//   }
// }
