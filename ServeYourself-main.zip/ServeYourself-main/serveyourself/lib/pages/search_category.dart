import 'package:flutter/material.dart';

class SearchCategoryPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Search Category')),
      body: Center(child: Text('Search Category Page')),
    );
  }
}
