import 'package:flutter/material.dart';

class SearchIngredientPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Search Ingredient')),
      body: Center(child: Text('Search Ingredient Page')),
    );
  }
}
