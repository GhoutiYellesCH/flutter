class ApiConstants {
  static const String baseUrl = 'https://api.example.com';
  static const String mealsEndpoint = '/meals';
}
